package com.example.timetable;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;

public class MainActivity extends AppCompatActivity {

    LinearLayout mon, tue, wed, thu, fri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);  //each layout(symbols each day) attribute
        mon = (LinearLayout)findViewById(R.id.mon);
        tue = (LinearLayout)findViewById(R.id.tue);
        wed = (LinearLayout)findViewById(R.id.wed);
        thu = (LinearLayout)findViewById(R.id.thu);
        fri = (LinearLayout)findViewById(R.id.fri);

        paint(getDate());  //paint red color in layout which means the day
    }
    public void paint(String date){
        if(date.startsWith("Mon")){
            mon.setBackgroundColor(Color.RED);
        }
        if(date.startsWith("Tue")){
            tue.setBackgroundColor(Color.RED);
        }
        if(date.startsWith("Wed")){
            wed.setBackgroundColor(Color.RED);
        }
        if(date.startsWith("Thu")){
            thu.setBackgroundColor(Color.RED);
        }
        if(date.startsWith("Fri")){
            fri.setBackgroundColor(Color.RED);
        }
    }
    public String getDate() {   //get date of the day
        return new Date().toString();
    }

}
